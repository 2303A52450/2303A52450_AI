export const CATEGORIES = [
  { id: 'electronics', name: 'Electronics', icon: '💻', color: '#FF6B35' },
  { id: 'fashion', name: 'Fashion', icon: '👗', color: '#E91E8C' },
  { id: 'home', name: 'Home & Living', icon: '🏠', color: '#4CAF50' },
  { id: 'books', name: 'Books', icon: '📚', color: '#2196F3' },
  { id: 'sports', name: 'Sports', icon: '⚽', color: '#FF9800' },
  { id: 'beauty', name: 'Beauty', icon: '✨', color: '#9C27B0' },
  { id: 'toys', name: 'Toys', icon: '🎮', color: '#F44336' },
  { id: 'grocery', name: 'Grocery', icon: '🛒', color: '#009688' },
];

export const PRODUCTS = [
  {
    id: 'p1', name: 'MacBook Pro 14" M3 Pro', category: 'electronics',
    price: 1999.99, originalPrice: 2299.99, rating: 4.8, reviewCount: 2341,
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80',
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80',
      'https://images.unsplash.com/photo-1611186871525-9fa06a6c6c9b?w=800&q=80',
    ],
    badge: 'Best Seller', inStock: true, stockCount: 45,
    description: 'The MacBook Pro 14" with M3 Pro chip delivers extraordinary performance. Featuring a stunning Liquid Retina XDR display, up to 22 hours of battery life, and advanced connectivity.',
    specs: { Processor: 'Apple M3 Pro', RAM: '18GB Unified Memory', Storage: '512GB SSD', Display: '14.2" Liquid Retina XDR', Battery: 'Up to 22 hours', Weight: '3.5 lbs' },
    tags: ['laptop', 'apple', 'macbook', 'pro'],
    reviews: [
      { id: 'r1', user: 'Alex M.', rating: 5, date: '2024-12-01', text: 'Incredible machine! The performance is unmatched and battery life is amazing.', helpful: 234 },
      { id: 'r2', user: 'Sarah K.', rating: 5, date: '2024-11-28', text: 'Best laptop I\'ve ever owned. Worth every penny.', helpful: 156 },
      { id: 'r3', user: 'John D.', rating: 4, date: '2024-11-15', text: 'Great performance but a bit pricey. Display is stunning.', helpful: 89 },
    ]
  },
  {
    id: 'p2', name: 'Sony WH-1000XM5 Headphones', category: 'electronics',
    price: 279.99, originalPrice: 399.99, rating: 4.7, reviewCount: 5892,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80'],
    badge: '30% Off', inStock: true, stockCount: 120,
    description: 'Industry-leading noise canceling with Auto NC Optimizer. Crystal clear hands-free calling and up to 30-hour battery life.',
    specs: { 'Driver Size': '30mm', 'Frequency Response': '4Hz-40,000Hz', Battery: '30 hours', Weight: '250g', Connectivity: 'Bluetooth 5.2', 'Noise Canceling': 'Yes' },
    tags: ['headphones', 'sony', 'wireless', 'noise-canceling'],
    reviews: [
      { id: 'r4', user: 'Mike R.', rating: 5, date: '2024-12-05', text: 'Best noise canceling headphones period. Wearing them all day at work.', helpful: 445 },
      { id: 'r5', user: 'Emma L.', rating: 4, date: '2024-11-30', text: 'Great sound quality and comfort. Battery lasts forever.', helpful: 210 },
    ]
  },
  {
    id: 'p3', name: 'iPhone 15 Pro Max', category: 'electronics',
    price: 1199.99, originalPrice: 1199.99, rating: 4.9, reviewCount: 8923,
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800&q=80'],
    badge: 'New', inStock: true, stockCount: 67,
    description: 'iPhone 15 Pro Max. Forged in titanium and featuring the groundbreaking A17 Pro chip, a customizable Action button, and the most powerful iPhone camera system ever.',
    specs: { Chip: 'A17 Pro', Storage: '256GB', Camera: '48MP + 12MP + 12MP', Display: '6.7" Super Retina XDR', Battery: '29 hours video', Weight: '221g' },
    tags: ['iphone', 'apple', 'smartphone'],
    reviews: [
      { id: 'r6', user: 'Chris P.', rating: 5, date: '2024-12-08', text: 'Absolutely incredible phone. The camera is mind-blowing.', helpful: 789 },
    ]
  },
  {
    id: 'p4', name: 'Nike Air Max 270', category: 'fashion',
    price: 129.99, originalPrice: 160.00, rating: 4.5, reviewCount: 3421,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80'],
    badge: 'Popular', inStock: true, stockCount: 200,
    description: 'The Nike Air Max 270 features Nike\'s biggest heel Air unit yet for an incredibly plush ride that feels as impossible as it looks.',
    specs: { Style: 'Casual', Closure: 'Lace-up', Upper: 'Mesh/Synthetic', Sole: 'Rubber', 'Air Unit': '270° Max Air', Weight: '12.3 oz' },
    tags: ['nike', 'shoes', 'sneakers', 'air max'],
    reviews: [
      { id: 'r7', user: 'Jordan T.', rating: 5, date: '2024-12-02', text: 'Super comfortable! Wear them every day.', helpful: 321 },
      { id: 'r8', user: 'Lisa M.', rating: 4, date: '2024-11-25', text: 'Great style and comfort. Runs a bit large.', helpful: 145 },
    ]
  },
  {
    id: 'p5', name: 'Samsung 65" QLED 4K TV', category: 'electronics',
    price: 1299.99, originalPrice: 1799.99, rating: 4.6, reviewCount: 1876,
    image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800&q=80'],
    badge: 'Deal', inStock: true, stockCount: 23,
    description: 'Experience breathtaking 4K resolution with Quantum Dot technology. Smart TV features with built-in streaming apps.',
    specs: { Display: '65" QLED 4K', Resolution: '3840x2160', HDR: 'Quantum HDR+', 'Refresh Rate': '120Hz', 'Smart TV': 'Tizen OS', Connectivity: '4x HDMI, 3x USB' },
    tags: ['samsung', 'tv', 'qled', '4k'],
    reviews: [
      { id: 'r9', user: 'Dave W.', rating: 5, date: '2024-11-20', text: 'Picture quality is stunning. Best TV purchase ever.', helpful: 567 },
    ]
  },
  {
    id: 'p6', name: 'Instant Pot Duo 7-in-1', category: 'home',
    price: 79.99, originalPrice: 99.99, rating: 4.7, reviewCount: 12453,
    image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80'],
    badge: 'Top Rated', inStock: true, stockCount: 345,
    description: '7-in-1 multi-use programmable pressure cooker, slow cooker, rice cooker, steamer, sauté, yogurt maker, and warmer.',
    specs: { Capacity: '6 Quart', Functions: '7-in-1', Programs: '13 built-in', Voltage: '120V 60Hz', Power: '1000W', Material: 'Stainless Steel' },
    tags: ['instant pot', 'cooking', 'kitchen'],
    reviews: [
      { id: 'r10', user: 'Maria S.', rating: 5, date: '2024-12-01', text: 'Changed my cooking! Makes meal prep so easy.', helpful: 890 },
    ]
  },
  {
    id: 'p7', name: 'Levi\'s 501 Original Jeans', category: 'fashion',
    price: 69.99, originalPrice: 89.99, rating: 4.4, reviewCount: 6789,
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&q=80'],
    badge: null, inStock: true, stockCount: 500,
    description: 'The original jean since 1873. The 501 Original is the foundation of all jeans. Straight fit, button fly.',
    specs: { Fit: 'Straight', Rise: 'Regular', Closure: 'Button fly', Material: '100% Cotton', Care: 'Machine Wash', Origin: 'USA' },
    tags: ['levis', 'jeans', 'denim', 'fashion'],
    reviews: []
  },
  {
    id: 'p8', name: 'Atomic Habits - James Clear', category: 'books',
    price: 14.99, originalPrice: 27.00, rating: 4.9, reviewCount: 45231,
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=800&q=80'],
    badge: '#1 Bestseller', inStock: true, stockCount: 999,
    description: 'No.1 New York Times bestseller. A revolutionary system to get 1 percent better every day.',
    specs: { Format: 'Hardcover', Pages: '320', Publisher: 'Avery', Language: 'English', ISBN: '978-0735211292', 'Pub Date': 'Oct 16, 2018' },
    tags: ['self-help', 'habits', 'productivity', 'james clear'],
    reviews: [
      { id: 'r11', user: 'Tom B.', rating: 5, date: '2024-12-03', text: 'Life changing book. Everyone should read this.', helpful: 2341 },
    ]
  },
  {
    id: 'p9', name: 'Dyson V15 Detect Vacuum', category: 'home',
    price: 649.99, originalPrice: 749.99, rating: 4.8, reviewCount: 2134,
    image: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1558317374-067fb5f30001?w=800&q=80'],
    badge: 'Premium', inStock: true, stockCount: 34,
    description: 'Laser reveals microscopic dust. Scientifically proves a deep clean. Automatically adapts power to the task.',
    specs: { Type: 'Cordless', Runtime: 'Up to 60 min', Suction: '240 AW', Filtration: 'HEPA', Weight: '6.8 lbs', Bin: '0.2 gallon' },
    tags: ['dyson', 'vacuum', 'cordless', 'cleaning'],
    reviews: []
  },
  {
    id: 'p10', name: 'Apple Watch Series 9', category: 'electronics',
    price: 399.99, originalPrice: 399.99, rating: 4.7, reviewCount: 3892,
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=80'],
    badge: 'New', inStock: true, stockCount: 89,
    description: 'Smarter. Brighter. Mightier. The Apple Watch Series 9 with the all-new S9 chip.',
    specs: { Chip: 'S9 SiP', Display: 'Always-On Retina', 'Water Resistance': '50m', GPS: 'Yes', 'Health Sensors': 'ECG, Blood Oxygen, Temperature', Battery: '18 hours' },
    tags: ['apple watch', 'smartwatch', 'wearable'],
    reviews: []
  },
  {
    id: 'p11', name: 'Yoga Mat Premium Non-Slip', category: 'sports',
    price: 45.99, originalPrice: 65.99, rating: 4.6, reviewCount: 8901,
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80'],
    badge: null, inStock: true, stockCount: 600,
    description: 'Extra thick 6mm premium yoga mat with excellent grip. Eco-friendly TPE material.',
    specs: { Thickness: '6mm', Size: '72" x 24"', Material: 'TPE', Weight: '2.5 lbs', 'Non-Slip': 'Yes', Includes: 'Carrying strap' },
    tags: ['yoga', 'fitness', 'exercise mat'],
    reviews: []
  },
  {
    id: 'p12', name: 'Charlotte Tilbury Pillow Talk Kit', category: 'beauty',
    price: 78.00, originalPrice: 95.00, rating: 4.8, reviewCount: 4523,
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&q=80',
    images: ['https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&q=80'],
    badge: 'Luxury', inStock: true, stockCount: 78,
    description: 'The iconic Pillow Talk collection featuring lip liner, lipstick, and mascara in Charlotte\'s most requested shades.',
    specs: { Set: '3 Pieces', Shade: 'Pillow Talk', Formula: 'Long-lasting', 'Cruelty-free': 'Yes', 'Paraben-free': 'Yes', 'Made in': 'UK' },
    tags: ['makeup', 'lipstick', 'beauty', 'charlotte tilbury'],
    reviews: []
  },
];

export const BANNERS = [
  {
    id: 'b1',
    title: 'Super Deals on Electronics',
    subtitle: 'Up to 40% off on top brands',
    cta: 'Shop Now',
    category: 'electronics',
    bg: 'from-slate-900 via-blue-950 to-slate-900',
    accent: '#3B82F6',
    img: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&q=80'
  },
  {
    id: 'b2',
    title: 'Fashion Forward',
    subtitle: 'New arrivals every week',
    cta: 'Explore',
    category: 'fashion',
    bg: 'from-rose-950 via-pink-900 to-slate-900',
    accent: '#F43F5E',
    img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80'
  },
  {
    id: 'b3',
    title: 'Home & Living Sale',
    subtitle: 'Transform your space today',
    cta: 'Discover',
    category: 'home',
    bg: 'from-emerald-950 via-teal-900 to-slate-900',
    accent: '#10B981',
    img: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=80'
  },
];
