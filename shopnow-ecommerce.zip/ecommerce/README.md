# 🛍️ ShopNow — Full-Stack eCommerce Platform

A feature-complete Amazon-like eCommerce application built as a single-file React app with full frontend functionality.

## 🚀 Quick Start

Simply open `index.html` in any modern browser — no build tools or installation required!

```bash
# Option 1: Direct open
open index.html

# Option 2: Using Python server
python3 -m http.server 3000
# Then visit http://localhost:3000

# Option 3: Using Node
npx serve .
```

---

## ✅ Features Implemented

### 🔐 Authentication System
- User registration with name, email, password
- Secure login / logout
- Password reset flow (email simulation)
- **Admin login:** `admin@shopnow.com` / `admin123`
- Credentials stored in localStorage (hashed in production)

### 🏠 Homepage
- Animated banner carousel with 3 rotating deals
- Category grid with 8 categories
- Featured products section
- Trending products section
- Promo banner (use code **WELCOME20** for 20% off)

### 🛍️ Product Features
- 12 real products across 8 categories
- Product images, price, star ratings, review counts
- Product detail page with:
  - Multiple image thumbnails
  - Specifications tab
  - Reviews tab
  - Description tab
- Add to cart with quantity selector
- Wishlist (heart) toggle on every product

### 🛒 Cart & Checkout
- Cart with quantity update (+/-) and remove
- Dynamic total calculation
- Promo code support (WELCOME20)
- Tax calculation (8%) + shipping
- Savings display

### 📍 Address Management
- Pre-loaded demo address
- Add new addresses during checkout and dashboard
- Delete addresses
- Select delivery address at checkout

### 💳 Payment System
- Saved card management (add/remove)
- 3 payment methods: Card, Cash on Delivery, UPI
- Mock secure checkout with order total display

### 📦 Orders
- Order confirmation page with order ID
- Order history in dashboard
- Order status (processing, shipped, delivered, pending)
- Items listed with images

### ❤️ Wishlist
- Dedicated wishlist page
- Add/remove from wishlist
- Move items to cart from wishlist
- Count badge on navbar

### 👤 User Dashboard
- Profile overview
- Order history
- Saved addresses
- Payment methods
- Wishlist management

### ⚙️ Admin Panel
- Access: `admin@shopnow.com` / `admin123`
- Dashboard stats (products, orders, revenue, users)
- Product management (add/delete)
- Order management with status display
- User management section

### 🔍 Search & Filter
- Search bar in navbar
- Filter by category
- Filter by price range (slider)
- Filter by minimum rating
- Sort by: Popular, Highest Rated, Price (asc/desc), Newest

---

## 🎨 Design

- **Color Palette:** Dark theme with vibrant orange (#FF6B35) accent
- **Typography:** Sora (headings/body) + JetBrains Mono (codes/prices)
- **Animations:** Fade-in, slide-in, shimmer, banner transitions
- **Responsive:** Mobile-friendly layout with adaptive grids

---

## 🏗️ Architecture

```
index.html
├── CSS Variables & Global Styles
├── React Components (vanilla React via CDN)
│   ├── App (state management hub)
│   ├── Navbar
│   ├── CategoryBar
│   ├── HomePage
│   │   ├── BannerSection
│   │   └── ProductCard
│   ├── ProductsPage (with FilterPanel)
│   ├── ProductDetailPage
│   ├── CartPage
│   ├── CheckoutPage (3-step flow)
│   ├── OrderSuccessPage
│   ├── AuthPage (login/register/reset)
│   ├── DashboardPage
│   ├── WishlistPage
│   └── AdminPage
├── Toast Notification System
└── localStorage persistence
```

---

## 💾 Data Persistence

All data is persisted in **localStorage**:
- `sn_user` — logged-in user session
- `sn_cart` — shopping cart
- `sn_wishlist` — wishlist items
- `sn_orders` — order history
- `sn_addrs` — saved addresses
- `sn_cards` — saved payment cards
- `sn_users` — registered user accounts

---

## 🔒 Security Notes

This is a **frontend-only demo**. For production:
- Implement a backend (Node.js/Express or Next.js)
- Hash passwords with bcrypt
- Use JWT for session management
- Integrate a real payment gateway (Stripe/PayPal)
- Use a real database (MongoDB/PostgreSQL)
- Add HTTPS + CSRF protection

---

## 📦 Production Stack Recommendation

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js + Tailwind CSS |
| Backend | Node.js + Express |
| Database | PostgreSQL + Prisma |
| Auth | NextAuth.js / JWT |
| Payments | Stripe |
| Images | Cloudinary |
| Hosting | Vercel + Railway |

---

## 📄 License

MIT — Free to use and modify.
